from django.apps import AppConfig


class NsappConfig(AppConfig):
    name = 'nsApp'
